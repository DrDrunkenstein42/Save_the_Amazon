# Save_the_Amazon

Authored- not_a_virus.exe

The project is essentially a web extension which returns the approximate magnitude of air and water pollution the environment suffers during the manufacture of a particular product one surfs on Amazon, and suggests more eco-friendly alternatives.
